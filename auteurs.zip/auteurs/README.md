Bonjour,

En terme fonctionnelle voilà les différents Use-Case qu'il faut implémenter :

* créer des auteurs,
* modifier les informations d'un auteur,
* créer des livres,
* associer un livre ou des livres à un auteur,
* lister les auteurs ayant comme livre en comun.

Pour la réalisation, vous avez le chois:

* Utiliser le projet template que je vous ai envoyé
* Faire un projet en from scratch avec l'outillage de votre chois 

Technologie à utiliser :

JAVA 8 ou 11
Spring boot avec l'ensemble des module necessaire au projet
Swagger doc ( non obligatoire )
Junit, mockito ( tu peux proposer une autre librairie si vous voulez )


Ppin important : l'exercice ne doit pas dépasser plus de 4h ou 5h 

livrable à envoyé d'içi 24h

Merci et bon courage 😊


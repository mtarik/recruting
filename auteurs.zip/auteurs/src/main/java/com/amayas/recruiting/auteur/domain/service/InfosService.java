package com.amayas.recruiting.auteur.domain.service;

public interface InfosService {

	String getCurrentVersion();
}

package com.amayas.recruiting.auteur.domain.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.Repository;

import com.amayas.recruiting.auteur.domain.model.InfosEntity;

public interface InfosRepository extends Repository<InfosEntity, String>{

	@Query("SELECT i.version FROM InfosEntity i")
	String get();
}

package com.amayas.recruiting.auteur.rest.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.amayas.recruiting.auteur.domain.service.InfosService;
import com.amayas.recruiting.auteur.rest.InfosResource;

@Service
public class InfosResourceImpl implements InfosResource{

	@Autowired
	private InfosService service;

	public String get() {
		return new StringBuilder()//
				.append("Current version is : ")//
				.append(service.getCurrentVersion())//
				.toString();
	}
	
	
	
}
